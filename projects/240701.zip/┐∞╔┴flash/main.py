from PIL import Image, ImageDraw, ImageFont
import random
import os
import jieba


works = input('Enter your text:')
works_list = jieba.lcut(works)
out_list = []
 
stopwords = ['：','“','！','”', '，', '。']


for i in works_list:
    if i not in stopwords:
        out_list.append(i)

print(out_list)


color = [(135, 206, 235), (224, 255, 255), (255, 255, 0),
         (255, 215, 0), (255, 165, 0), (255, 99, 71), (255, 182, 193), (173, 216, 230)]
for i in range(random.randint(1, 10)):
    color.append((random.randint(100, 255), random.randint(100, 255), random.randint(100, 255)))

fonts = os.listdir('./font')

    
#创建每一帧带有文字的图片
for i in range(len(out_list)):
    font = ImageFont.truetype('./font/'+random.choice(fonts), 100)
    b = Image.new('RGBA', (800, 450), (0, 0, 0, 255))
    draw = ImageDraw.Draw(b)
    draw.text((300, 200), out_list[i], random.choice(color), font=font)
    b.save(f'./images/{out_list[i]}.png')


#合成动图
frames = []
for i in out_list:
    img = Image.open('./images/' + str(i) + '.png')
    frames.append(img)



frames[0].save('flash.gif', save_all=True,
               append_images=frames[1:], duration=random.randint(300, 500))



